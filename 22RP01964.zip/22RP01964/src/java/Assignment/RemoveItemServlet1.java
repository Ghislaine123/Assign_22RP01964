
package Assignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RemoveItemServlet1 extends HttpServlet {

  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
   String item = request.getParameter("item");
        if (item != null && !item.isEmpty()) {
            Cookie[] cookies = request.getCookies();
            if (cookies != null) {
                for (Cookie cookie : cookies) {
                    if ("cart".equals(cookie.getName())) {
                        ArrayList<String> cartItems = new ArrayList<>(Arrays.asList(URLDecoder.decode(cookie.getValue(), "UTF-8").split(",")));
                        cartItems.remove(item);
                        String cartValue = URLEncoder.encode(String.join(",", cartItems), "UTF-8");
                        if (cartItems.isEmpty()) {
                            cookie.setMaxAge(0);
                        } else {
                            cookie.setValue(cartValue);
                            cookie.setMaxAge(60 * 60 * 24);
                        }
                        response.addCookie(cookie);
                        break;
                    }
                }
            }
        }
        response.sendRedirect("view-cart.html");
    }
}
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
     doPost(request,response);
}
}